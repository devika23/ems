from django.db import models

class Director(models.Model):
    director  = models.CharField(max_length = 50)
    dir_id = models.IntegerField(unique = True)
    password = models.CharField(max_length = 15)
    def __str__(self):
        return self.director
               
class Manager(models.Model):
    manager = models.CharField(max_length=50)
    man_id = models.IntegerField(unique = True)
    password = models.CharField(max_length=15)
    director = models.ForeignKey('Director', on_delete =  models.SET_NULL, null = True)
    def __str__(self):
        return self.manager
        
class Employee(models.Model):
    emp_name = models.CharField(max_length=50)
    emp_id = models.IntegerField(unique = True)
    password = models.CharField(max_length=15)
    used_technologies = models.ForeignKey('Technologies', on_delete =  models.SET_NULL, null = True)
    skills = models.ForeignKey('Skills', on_delete =  models.SET_NULL, null = True)
    projects = models.ForeignKey('Projects', on_delete =  models.SET_NULL, null = True)
    manager = models.ForeignKey('Manager', on_delete=models.SET_NULL, null=True)
    director = models.ForeignKey('Director', on_delete =  models.SET_NULL, null = True)
    def __str__(self):
        return self.emp_name

class Technologies(models.Model):
    used_technologies = models.CharField(max_length = 20)
    def __str__(self):
        return self.used_technologies

class Skills(models.Model):
    skills = models.CharField(max_length = 20)
    def __str__(self):
        return self.skills

class Projects(models.Model):
    projects = models.CharField(max_length = 100)
    def __str__(self):
        return self.projects