from django.contrib import admin
from . import views
from django.urls import path
urlpatterns = [
    path('home', views.home, name = "home"),

    path('director', views.director, name = "director"),
    path('addDirForm', views.addDirForm, name = "addDirForm"),
    path('addDir', views.addDir, name = "addDir"),
    path('updateDirForm/<int:id>', views.updateDirForm, name = "updateDirForm"),
    path('updateDir/<int:id>', views.updateDir, name = "updateDir"),
    path('delDir/<int:id>', views.delDir, name = "delDir"),
    path('dirList', views.dirList, name = "dirList"),
    path('dirDetailForm', views.dirDetailForm, name = "dirDetailForm"),  
    path('searchDirById', views.searchDirById, name = "searchDirById"),
    
    path('manager', views.manager, name = "manager"),
    path('manDashboard', views.manDashboard, name = "manDashboard"),
    path('addManForm', views.addManForm, name = "addManForm"),
    path('addMan', views.addMan, name = "addMan"),
    path('updateManForm/<int:id>', views.updateManForm, name = "updateManForm"),
    path('updateMan/<int:id>', views.updateMan, name = "updateMan"),
    path('delMan/<int:id>', views.delMan, name = "delMan"),
    path('manList', views.manList, name = "manList"),
    path('manDetailForm', views.manDetailForm, name = "manDetailForm"),  
    path('searchManById', views.searchManById, name = "searchManById"),

    path('employee', views.employee, name = "employee"),
    path('empDashboard', views.empDashboard, name = "empDashboard"),
    path('addEmpForm', views.addEmpForm, name = "addEmpForm"),
 
    path('addEmp', views.addEmp, name = "addEmp"),
    path('updateEmpForm/<int:id>', views.updateEmpForm, name = "updateEmpForm"),
    path('updateEmp/<int:id>', views.updateEmp, name = "updateEmp"),
    path('delEmp/<int:id>', views.delEmp, name = "delEmp"),
    path('empList', views.empList, name = "empList"),
    path('search', views.search, name = "search"),
    #path('empsDetailForm', views.empDetailForm, name = "empDetailForm"),
    path('searchEmpById', views.searchEmpById, name = "searchEmpById"),  
    #path('empsDetailForm1', views.empDetailForm1, name = "empDetailForm1"),
    path('searchEmpByTech', views.searchEmpByTech, name = "searchEmpByTech"),  
    #path('empsDetailForm2', views.empDetailForm2, name = "empDetailForm2"),
    path('searchEmpBySkill', views.searchEmpBySkill, name = "searchEmpBySkill"),  
    #path('empsDetailForm3', views.empDetailForm3, name = "empDetailForm3"),
    path('searchEmpByProject', views.searchEmpByProject, name = "searchEmpByProject"),    
]