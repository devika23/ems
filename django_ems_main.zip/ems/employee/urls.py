from django.contrib import admin
from . import views
from django.urls import path
urlpatterns = [
    path('home', views.home, name = "home"),
    
    path('director', views.director, name = "director"),
    path('dirDshboard', views.dirDashboard, name = "dirDashboard"),
    path('addDirForm', views.addDirForm, name = "addDirForm"),
    path('addDir', views.addDir, name = "addDir"),
    path('updateDirForm/<int:id>', views.updateDirForm, name = "updateDirForm"),
    path('updateDir/<int:id>', views.updateDir, name = "updateDir"),
    path('delDir/<int:id>', views.delDir, name = "delDir"),
    path('dirList', views.dirList, name = "dirList"),  
    path('searchDirById', views.searchDirById, name = "searchDirById"),
    
    path('manager', views.manager, name = "manager"),
    path('manDashboard', views.manDashboard, name = "manDashboard"),
    path('addManForm', views.addManForm, name = "addManForm"),
    path('addMan', views.addMan, name = "addMan"),
    path('updateManForm/<int:id>', views.updateManForm, name = "updateManForm"),
    path('updateMan/<int:id>', views.updateMan, name = "updateMan"),
    path('delMan/<int:id>', views.delMan, name = "delMan"),
    path('manList', views.manList, name = "manList"),  
    path('searchManById', views.searchManById, name = "searchManById"),

    path('employee', views.employee, name = "employee"),
    path('empDashboard', views.empDashboard, name = "empDashboard"),
    path('empSearch', views.empSearch, name = "empSearch"),
    path('addEmpForm', views.addEmpForm, name = "addEmpForm"),
     path('addEmp', views.addEmp, name = "addEmp"),
    path('updateEmpForm/<int:id>', views.updateEmpForm, name = "updateEmpForm"),
    path('updateEmp/<int:id>', views.updateEmp, name = "updateEmp"),
    path('delEmp/<int:id>', views.delEmp, name = "delEmp"),
    path('empList', views.empList, name = "empList"),
    path('search', views.search, name = "search"),
]