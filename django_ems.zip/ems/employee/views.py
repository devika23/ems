from django.shortcuts import render
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from employee.forms import EmpForm,ManForm,DirForm
from employee.models import Employee, Manager, Director
from django.contrib.auth.decorators import login_required
from django.contrib import messages
# Create your views here.
def home(request):
    return render(request,'home.html')

def director(request):
    return render(request,'login.html')
@login_required
def dirDashboard(request):
    result = "Director Successfully LoggedIn"
    return render(request, 'dirDashboard.html', {'result':result})
def addDirForm(request):
    form=DirForm()
    return render(request,'addDirForm.html',{'form':form})
def addDir(request):
    if request.method == "POST":  
       var = DirForm(data = request.POST)
       if Director.objects.filter(dir_id = var['dir_id'].value()).exists():
          obj = DirForm(request.POST)
          messages.success(request,"Director Existed With the given Id")
       else:
          obj = DirForm(request.POST)
          if obj.is_valid():
             obj.save()
             messages.success(request, "Director Added Successfully")
          else:
            obj = DirForm(request.POST)
            messages.success(request,"please Choose correct Form")
       return render(request,'addDirForm.html',{'form':obj})
def updateDirForm(request, id):
    var = Director.objects.get(id = id)
    form=DirForm(instance = var)
    return render(request,'updateDirForm.html',{'form':form,'id':id})
def updateDir(request, id):
    if request.method == "POST":  
        data1 = Director.objects.get(id= id)
        form = DirForm(request.POST,instance = data1)
        if form.is_valid():
            form.save()
            result="Director Updated Successfully"
        else:
            result="Please Choose Correct Form"
        return render(request,'result.html',{'result':result})
def delDir(request, id): 
    data = Director.objects.get(id= id)
    data.delete()
    result = "Director Removed Successfully"
    return render(request,'result.html',{'result':result})
def dirList(request):
    dirList = Director.objects.all()
    paginator = Paginator(dirList, 5) # Show 5 rows per page.
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'dirDetails.html', {'page_obj': page_obj})
def dirDetailForm(request):
    return render(request,'dirDetailForm.html')
def searchDirById(request):
    if Director.objects.filter(dir_id = request.POST['dir_id']).exists():
       obj=Director.objects.get(dir_id =request.POST['dir_id'])
       text={'data':obj}
       return render(request, 'dirDetail.html',text)
    else:
        data="Director not Existed with the given Id"
        text={'result':data}
        return render(request, 'result.html',text)


def manager(request):
    return render(request,'man_login.html')
@login_required
def manDashboard(request):
    result = "Manager Successfully LoggedIn"
    return render(request, 'manDashboard.html', {'result':result})
def addManForm(request):
    form=ManForm()
    return render(request,'addManForm.html',{'form':form})
def addMan(request):
    if request.method == "POST":  
       var = ManForm(data = request.POST)
       if Manager.objects.filter(man_id = var['man_id'].value()).exists():
          obj = ManForm(request.POST)
          messages.success(request,"Manager Existed With the given Id")
       else:
          obj = ManForm(request.POST)
          if obj.is_valid():
             obj.save()
             messages.success(request, "Manager Added Successfully")
          else:
            obj = ManForm(request.POST)
            messages.success(request,"please Choose correct Form")
       return render(request,'addManForm.html',{'form':obj})
def updateManForm(request, id):
    var = Manager.objects.get(id = id)
    form=ManForm(instance  = var)
    return render(request,'updateManForm.html',{'form':form,'id':id})
def updateMan(request, id):
    if request.method == "POST":  
        data1 = Manager.objects.get(id= id)
        form = ManForm(request.POST,instance = data1)
        if form.is_valid():
            form.save()
            result="Manager Updated Successfully"
        else:
            result="Please Choose Correct Form"
        return render(request,'man_result.html',{'result':result})
def delMan(request, id): 
    data = Manager.objects.get(id= id)
    data.delete()
    result = "Manager Removed Successfully"
    return render(request, 'man_result.html',{'result':result})
def manList(request):
    manList = Manager.objects.all()
    paginator = Paginator(manList, 5) # Show 5 rows per page.
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'manDetails.html', {'page_obj': page_obj})
def manDetailForm(request):
    return render(request,'manDetailForm.html')
def searchManById(request):
    if Manager.objects.filter(man_id = request.POST['man_id']).exists():
       obj=Manager.objects.get(man_id =request.POST['man_id'])
       text={'data':obj}
       return render(request, 'manDetail.html',text)
    else:
        data="Manager not Existed with the given Id"
        text={'result':data}
        return render(request, 'man_result.html',text)


def employee(request):
    return render(request,'emp_login.html')
@login_required
def empDashboard(request):
    result = "Employee Successfully LoggedIn"
    return render(request, 'empDashboard.html', {'result':result})
def addEmpForm(request):
    form=EmpForm()
    return render(request,'addEmpForm.html',{'form':form})
def addEmp(request):
    if request.method == "POST":  
       var = EmpForm(data = request.POST)
       if Employee.objects.filter(emp_id = var['emp_id'].value()).exists():
          obj = EmpForm(request.POST)
          messages.success(request,"Employee Existed With the given Id")
       else:
          obj = EmpForm(request.POST)
          if obj.is_valid():
             obj.save()
             messages.success(request, "Employee Added Successfully")
          else:
            obj = EmpForm(request.POST)
            messages.success(request,"please Choose correct Form")
       return render(request,'addEmpForm.html',{'form':obj})
def updateEmpForm(request, id):
    var = Employee.objects.get(id = id)
    form=EmpForm(instance = var)
    return render(request,'updateEmpForm.html',{'form':form,'id':id})
def updateEmp(request, id):
    if request.method == "POST":  
        data1 = Employee.objects.get(id= id)
        form = EmpForm(request.POST,instance = data1)
        if form.is_valid():
            form.save()
            result="Employee Updated Successfully"
        else:
            result="Please Choose Correct Form"
        return render(request,'emp_result.html',{'result':result})
def delEmp(request, id): 
    data = Employee.objects.get(id= id)
    data.delete()
    result = "Employee Removed Successfully"
    return render(request, 'emp_result.html',{'result':result})
def empList(request):
    empList = Employee.objects.all()
    paginator = Paginator(empList, 5) # Show 5 rows per page.
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'empDetails.html', {'page_obj': page_obj})
def search(request):
    if request.method=="POST":
        value = request.POST.get('get_value')
        if value == 'SearchEmployeeById':
           return render(request,'empDetailForm.html')
        elif value == 'SearchEmployeeByTechnology':
           return render(request,'empDetailForm1.html')
        elif value == 'SearchEmployeeBySkills':
            return render(request, 'empDetailForm2.html')
        elif value == 'SearchEmployeeByProject':
            return render(request, 'empDetailForm3.html')
def searchEmpById(request):
    if Employee.objects.filter(emp_id = request.POST['emp_id']).exists():
       obj= Employee.objects.filter(emp_id = request.POST['emp_id'])
       text={'data1':obj}
       return render(request, 'empDetail.html',text)
    else:
        data="Employee not Existed with the given Id"
        text={'result':data}
        return render(request, 'emp_result.html',text)
def searchEmpByTech(request):
    if Employee.objects.filter(used_technologies__used_technologies = request.POST['used_technologies']).exists():
       obj= Employee.objects.filter(used_technologies__used_technologies = request.POST['used_technologies'])
       text={'data1':obj}
       return render(request, 'empDetail.html',text)
    else:
        data="Employee not Existed with the given Technology"
        text={'result':data}
        return render(request, 'emp_result.html',text)
def searchEmpBySkill(request):
    if Employee.objects.filter(skills__skills = request.POST['skills']).exists():
       obj= Employee.objects.filter(skills__skills = request.POST['skills'])
       text={'data1':obj}
       return render(request, 'empDetail.html',text)
    else:
        data="Employee not Existed with the Skills"
        text = {'result':data}
        return render(request, 'emp_result.html',text)
def searchEmpByProject(request):
    if Employee.objects.filter(projects__projects = request.POST['projects']).exists():
       obj= Employee.objects.filter(projects__projects = request.POST['projects'])
       text={'data1':obj}
       return render(request, 'empDetail.html',text)
    else:
        data="Employee not Existed with the given Project"
        text={'result':data}
        return render(request, 'emp_result.html',text)