from django.contrib import admin

# Register your models here.
from employee.models import Manager, Director, Employee, Projects, Skills, Technologies
admin.site.register(Employee)
admin.site.register(Manager)
admin.site.register(Director)
admin.site.register(Projects)
admin.site.register(Skills)
admin.site.register(Technologies)