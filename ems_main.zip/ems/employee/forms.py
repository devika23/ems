from django import forms
from employee.models import Employee, Manager, Director

class DirForm(forms.ModelForm):
    password = forms.CharField(max_length=15, widget=forms.PasswordInput)
    class Meta:
        model = Director
        fields = '__all__'

class ManForm(forms.ModelForm):
    password = forms.CharField(max_length=15, widget=forms.PasswordInput)
    class Meta:
        model = Manager
        fields = '__all__'
        
class EmpForm(forms.ModelForm):
    password = forms.CharField(max_length=15, widget=forms.PasswordInput)
    class Meta:
        model = Employee
        fields = '__all__'