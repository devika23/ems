from django import forms
from employee.models import Employee, Manager, Director
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit

class DirForm(forms.ModelForm):
    password = forms.CharField(max_length=15, widget=forms.PasswordInput)
    def __init__(self, *args, **kwargs):
        super(DirForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()  
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-lg-2'
        self.helper.field_class = 'col-lg-8'
        self.helper.add_input(Submit('submit', 'Submit', css_class='btn-primary'))
    class Meta:
        model = Director
        fields = '__all__'

class ManForm(forms.ModelForm):
    password = forms.CharField(max_length=15, widget=forms.PasswordInput)
    def __init__(self, *args, **kwargs):
        super(ManForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()  
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-lg-2'
        self.helper.field_class = 'col-lg-8'
        self.helper.add_input(Submit('submit', 'Submit', css_class='btn-primary'))
    class Meta:
        model = Manager
        fields = '__all__'
        
class EmpForm(forms.ModelForm):
    password = forms.CharField(max_length=15, widget=forms.PasswordInput)
    def __init__(self, *args, **kwargs):
        super(EmpForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()  
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-lg-2'
        self.helper.field_class = 'col-lg-8'
        self.helper.add_input(Submit('submit', 'Submit', css_class='btn-primary'))
    class Meta:
        model = Employee
        fields = '__all__'