from django.db import models
from django.core.exceptions import ValidationError

def dirNameCheck(director):
    if len(director) > 20:
        raise ValidationError("Please Enter the Name Within 20 letters")
def dirIdCheck(dir_id):
    length = [char for char in str(dir_id)]
    if len(length) > 4:
        raise ValidationError("Id must contain 4 characters")
def dirPassCheck(password):
    spl_char = "[~\!@#\$%\^&\*\(\)_\+{}\":;'\[\]]"
    if not any(char.isdigit() for char in password):
        raise ValidationError("Password must contain a digit")
    elif not any(char.isalpha() for char in password):
        raise ValidationError("Password must contain alpha character")
    elif not any(char in spl_char for char in password):
        raise ValidationError("Password must contain special characters")
    elif len(password) < 8:
        raise ValidationError("Password must contain 8 Characters")

class Director(models.Model):
    director  = models.CharField(max_length = 30, validators = [dirNameCheck])
    dir_id = models.IntegerField(unique = True, validators = [dirIdCheck])
    password = models.CharField(max_length = 15, validators = [dirPassCheck])
    def __str__(self):
        return self.director
               

def manNamecheck(manager):
    if len(manager) > 20:
        raise ValidationError("Please Enter the Name Within 20 letters")
def manIdCheck(man_id):
    length = [char for char in str(man_id)]
    if len(length) > 4:
        raise ValidationError("Id must contain 4 characters")
def manPassCheck(password):
    spl_char = "[~\!@#\$%\^&\*\(\)_\+{}\":;'\[\]]"
    if not any(char.isdigit() for char in password):
        raise ValidationError("Password must contain a digit")
    elif not any(char.isalpha() for char in password):
        raise ValidationError("Password must contain alpha character")
    elif not any(char in spl_char for char in password):
        raise ValidationError("Password must contain special characters")
    elif len(password) < 8:
        raise ValidationError("Password must contain 8 Characters")

class Manager(models.Model):
    manager = models.CharField(max_length=30, validators =  [manNamecheck])
    man_id = models.IntegerField(unique = True, validators = [manIdCheck])
    password = models.CharField(max_length=15, validators = [manPassCheck])
    director = models.ForeignKey('Director', on_delete =  models.SET_NULL, null = True)
    def __str__(self):
        return self.manager
        

def empNamecheck(emp_name):
    if len(emp_name) > 20:
        raise ValidationError("Please Enter the Name Within 20 letters")
def empIdCheck(emp_id):
    length = [char for char in str(emp_id)]
    if len(length) > 4:
        raise ValidationError("Id must contain 4 characters")
def empPassCheck(password):
    spl_char = "[~\!@#\$%\^&\*\(\)_\+{}\":;'\[\]]"
    if not any(char.isdigit() for char in password):
        raise ValidationError("Password must contain a digit")
    elif not any(char.isalpha() for char in password):
        raise ValidationError("Password must contain alpha character")
    elif not any(char in spl_char for char in password):
        raise ValidationError("Password must contain special characters")
    elif len(password) < 8:
        raise ValidationError("Password must contain 8 Characters")
def empTechcheck(used_technologies):
    if len(used_technologies) > 20:
        raise ValidationError("Please Enter the data Within 20 letters")
def empSkillCheck(skills):
    if len(director) > 20:
        raise ValidationError("Please Enter the data Within 20 letters")
def empProcheck(projects):
    if len(projects) > 50:
        raise ValidationError("Please Enter the data Within 50 letters")

class Employee(models.Model):
    emp_name = models.CharField(max_length=30, validators = [empNamecheck])
    emp_id = models.IntegerField(unique = True, validators = [empIdCheck])
    password = models.CharField(max_length=15, validators = [empPassCheck])
    used_technologies = models.ForeignKey('Technologies', on_delete =  models.SET_NULL, null = True)
    skills = models.ForeignKey('Skills', on_delete =  models.SET_NULL, null = True)
    projects = models.ForeignKey('Projects', on_delete =  models.SET_NULL, null = True)
    manager = models.ForeignKey('Manager', on_delete=models.SET_NULL, null=True)
    director = models.ForeignKey('Director', on_delete =  models.SET_NULL, null = True)
    def __str__(self):
        return self.emp_name

class Technologies(models.Model):
    used_technologies = models.CharField(max_length = 30, validators = [empTechcheck])
    def __str__(self):
        return self.used_technologies

class Skills(models.Model):
    skills = models.CharField(max_length = 30, validators = [empSkillCheck])
    def __str__(self):
        return self.skills

class Projects(models.Model):
    projects = models.CharField(max_length = 100, validators = [empProcheck])
    def __str__(self):
        return self.projects